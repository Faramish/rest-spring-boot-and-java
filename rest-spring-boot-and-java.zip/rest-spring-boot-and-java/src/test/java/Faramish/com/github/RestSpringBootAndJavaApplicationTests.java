package Faramish.com.github;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestSpringBootAndJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
