package Faramish.com.github;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestSpringBootAndJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestSpringBootAndJavaApplication.class, args);
	}

}
